Deno.test("intentional failure", () => { throw Error("expected diagnostic failure"); });
