import { assertEquals, assertRejects } from "jsr:@std/assert@1.0.19";
import { startProductionApp } from "/home/aawei/searcher/.worktrees/issue-167/web/e2e/helpers/production-app.ts";
Deno.test("production fixture closes listener and removes its own directory", async () => {
    const a = await startProductionApp();
    const b = await startProductionApp();
    if (a.origin === b.origin || a.tempDir === b.tempDir || a.store === b.store) throw Error("shared fixture");
    console.log("FIXTURE_PAIR " + JSON.stringify({ a: { origin: a.origin, directory: a.tempDir }, b: { origin: b.origin, directory: b.tempDir } }));
    await a.close();
    await assertRejects(() => Deno.stat(a.tempDir), Deno.errors.NotFound);
    await assertRejects(() => fetch(a.origin));
    assertEquals((await Deno.stat(b.tempDir)).isDirectory, true);
    await b.close();
    await assertRejects(() => Deno.stat(b.tempDir), Deno.errors.NotFound);
});
