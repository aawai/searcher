Deno.test("b ordered", async (t) => {
console.log(JSON.stringify({file:"b",event:"start",time:Date.now()}));
let state=0;
await t.step("first", () => {state=1;});
await new Promise(r=>setTimeout(r,120));
await t.step("second", () => {if(state!==1) throw Error("order");});
console.log(JSON.stringify({file:"b",event:"end",time:Date.now()}));
});
