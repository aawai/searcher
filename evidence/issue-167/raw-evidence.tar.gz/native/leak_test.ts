Deno.test("intentional resource leak", () => { Deno.listen({port:0,hostname:"127.0.0.1"}); });
