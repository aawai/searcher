import { chromium } from "playwright";
import { startProductionApp } from "/home/aawei/searcher/.worktrees/issue-167/web/e2e/helpers/production-app.ts";
Deno.test("native signal probe with real HTTP and Chromium", async () => {
    const app = await startProductionApp();
    const browser = await chromium.launch({ args: ["--no-sandbox"], handleSIGTERM: false });
    try {
        const page = await browser.newPage();
        await page.goto(app.origin);
        console.log("SIGNAL_READY " + JSON.stringify({ origin: app.origin, tempDir: app.tempDir }));
        const { promise, resolve } = Promise.withResolvers<void>();
        setTimeout(resolve, 3_600_000);
        await promise;
    } finally {
        await browser.close();
        await app.close();
    }
});
