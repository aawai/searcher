import { chromium } from "playwright";
import { startProductionApp } from "/home/aawei/searcher/.worktrees/issue-167/web/e2e/helpers/production-app.ts";
const app = await startProductionApp();
const browser = await chromium.launch({ handleSIGTERM: false, args: ["--no-sandbox"] });
const gate = Promise.withResolvers<void>();
try {
    const page = await browser.newPage({ viewport: { width: 1280, height: 800 } });
    await page.route(/\/api\/search\/suggestions\?/, async (route) => {
        await gate.promise;
        await route.fulfill({
            status: 200,
            contentType: "application/json",
            body: JSON.stringify({ status: true, data: [
                { text: "late popup reproduction", source: "engine", engine: "google" },
            ] }),
        });
    });
    await page.goto(app.origin);
    const input = page.locator("#search-query");
    await input.waitFor({ state: "visible" });
    const requested = page.waitForRequest(/\/api\/search\/suggestions\?/);
    await input.fill("late popup");
    await requested;
    await input.evaluate((node) => node.blur());
    const completed = page.waitForResponse(/\/api\/search\/suggestions\?/);
    gate.resolve();
    await (await completed).finished();
    await page.evaluate(async () => {
        for (let frame = 0; frame < 2; frame++) {
            const { promise, resolve } = Promise.withResolvers<number>();
            requestAnimationFrame(resolve);
            await promise;
        }
    });
    const result = {
        focused: await input.evaluate((node) => document.activeElement === node),
        query: await input.inputValue(),
        suggestionsVisible: await page.getByRole("listbox", { name: "搜索建议" }).isVisible(),
    };
    await page.screenshot({ path: "/tmp/searcher-167-benchmark/popup-before.png" });
    await Deno.writeTextFile("/tmp/searcher-167-benchmark/popup-before.json", JSON.stringify(result, null, 2));
    console.log(JSON.stringify(result));
    if (!result.focused && result.suggestionsVisible) throw new Error("Confirmed: late suggestions reopen after search loses focus");
} finally {
    gate.resolve();
    await browser.close();
    await app.close();
}
